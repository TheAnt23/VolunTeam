package com.BH44HO.volunteam;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {

    private ArrayList<Events> dataSet;
    private Context context;

    public CustomAdapter(ArrayList<Events> dataSet, Context context) {
        this.dataSet = dataSet;
        this.context = context;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView textViewName;
        TextView textViewDescription;
        TextView textViewType;
        TextView textViewEdate;
        TextView textViewEtime;
        TextView textViewPhonenumber;
        TextView textViewLocation;


        public MyViewHolder(View itemView) {
            super(itemView);
            this.textViewName = itemView.findViewById(R.id.textViewName);
            this.textViewDescription = itemView.findViewById(R.id.textViewDescription);
            this.textViewType = itemView.findViewById(R.id.textViewType);
            this.textViewEdate = itemView.findViewById( R.id.textViewEdate );
            this.textViewEtime = itemView.findViewById( R.id.textViewEtime );
            this.textViewPhonenumber = itemView.findViewById(R.id.textViewPhonenumber);
            this.textViewLocation = itemView.findViewById(R.id.textViewLocation);


        }
    }
    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent,
                                           int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.card_layout, parent, false);


        MyViewHolder myViewHolder = new MyViewHolder(view);
        return myViewHolder;
    }
    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int listPosition) {

        final TextView textViewName = holder.textViewName;
        final TextView textViewDescription = holder.textViewDescription;
        final TextView textViewType = holder.textViewType;
        final TextView textViewEdate = holder.textViewEdate;
        final TextView textViewEtime = holder.textViewEtime;
        final TextView textViewLocation = holder.textViewLocation;
        final TextView textViewPhonenumber = holder.textViewPhonenumber;


        textViewName.setText(dataSet.get(listPosition).getName());
        textViewDescription.setText(dataSet.get(listPosition).getDescription());
        textViewType.setText(dataSet.get(listPosition).getType());
        textViewEdate.setText(dataSet.get(listPosition).getEdate());
        textViewEtime.setText( dataSet.get(listPosition).getEtime());
        textViewLocation.setText(dataSet.get(listPosition).getLocation());
        textViewPhonenumber.setText(dataSet.get(listPosition).getPhonenumber());



        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent toModify = new Intent(v.getContext(),ManageEvent.class);
                toModify.putExtra("id",String.valueOf(dataSet.get(listPosition).getId()));
                toModify.putExtra("event_name",textViewName.getText().toString());
                toModify.putExtra("event_description",textViewDescription.getText().toString());
                toModify.putExtra("event_type",textViewType.getText().toString());
                toModify.putExtra("event_date",textViewEdate.getText().toString());
                toModify.putExtra("event_time",textViewEtime.getText().toString());
                toModify.putExtra("event_Contact_Details",textViewPhonenumber.getText().toString());
                toModify.putExtra("event_location",textViewLocation.getText().toString());


                //   toModify.putExtra();
                context.startActivity(toModify);
            }
        });
    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }
}