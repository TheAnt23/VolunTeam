package com.BH44HO.volunteam;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.EditText;

import java.util.ArrayList;

public class SearchEvent extends AppCompatActivity {

    private static final String TAG = "SearchEvent";
    private ArrayAdapter adapter;

    private DBManager db;
    private ArrayList<Events> dataList;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_search_event );

        RecyclerView list = (RecyclerView) findViewById( R.id.theList );
        EditText theFilter = (EditText) findViewById( R.id.searchFilter );
        Log.d( TAG, "onCreate: Started." );






    }

}
