package com.BH44HO.volunteam;

import android.content.Intent;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.SearchEvent;
import android.widget.Toast;

public class Dashboard extends AppCompatActivity {
    private DrawerLayout mDrawerlayout;
    private ActionBarDrawerToggle mToggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        mDrawerlayout = (DrawerLayout) findViewById(R.id.drawer);
        mToggle = new ActionBarDrawerToggle(this, mDrawerlayout,R.string.open,R.string.close);
        mDrawerlayout.addDrawerListener(mToggle);
        mToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (mToggle.onOptionsItemSelected(item)) {

            if (item.getItemId() == R.id.db) {
                Intent intent = new Intent(this, UserMenu.class);
                startActivity(intent);
            } else if (item.getItemId() == R.id.notifications) {
                Toast.makeText(this, "You clicked Notifications", Toast.LENGTH_SHORT).show();
            } else if (item.getItemId() == R.id.nearby) {
                Toast.makeText(this, "You clicked Nearby Events", Toast.LENGTH_SHORT).show();
            }  else if (item.getItemId() == R.id.create) {
                Intent intent = new Intent(this, RegisterEvent.class);
                startActivity(intent);
            } else if (item.getItemId() == R.id.search) {
                Intent intent = new Intent(this, SearchEvent.class);
                startActivity(intent);
            } else if (item.getItemId() == R.id.respond) {
                Toast.makeText(this, "You clicked Respond Events", Toast.LENGTH_SHORT).show();
            } else if (item.getItemId() == R.id.logout) {
                Intent intent = new Intent(this, LoginPage.class);
                startActivity(intent);
            } else {
                return super.onOptionsItemSelected(item);
            }
            return true;
        }
        return true;
    }
}