package com.BH44HO.volunteam;

public class Events {
    private int id;
    private String name;
    private String description;
    private String type;
    private String edate;
    private String etime;
    private String phonenumber;
    private String location;


    public Events(){}

    public Events(int id, String name, String description, String type, String edate, String etime, String phonenumber, String location){

        this.id=id;
        this.name = name;
        this.description = description;
        this.type = type;
        this.edate = edate;
        this.etime = etime;
        this.phonenumber = phonenumber;
        this.location = location;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getEdate() {
        return edate;
    }

    public void setEdate(String edate) {
        this.edate = edate;
    }

    public String getEtime() {
        return etime;
    }

    public void setEtime(String etime) {
        this.etime = etime;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }


}
