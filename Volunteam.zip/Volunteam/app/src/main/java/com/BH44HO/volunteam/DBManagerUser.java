package com.BH44HO.volunteam;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class DBManagerUser {

    private DatabaseHelper db;
    private Context context;
    private SQLiteDatabase database;

    public DBManagerUser(Context c){context = c;}

    public DBManagerUser open() throws SQLException{
        db = new DatabaseHelper( context );
        database = db.getWritableDatabase();
        database = db.getReadableDatabase();
        return this;
    }

    public void close(){db.close();}

    public void insert(String fullname, String username, String password, String email, String phonenumber){
        open();
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.Fullname, fullname);
        contentValues.put(DatabaseHelper.Username, username);
        contentValues.put(DatabaseHelper.Password, password);
        contentValues.put(DatabaseHelper.Email, email);
        contentValues.put(DatabaseHelper.Phonenumber, phonenumber);
        database.insert(DatabaseHelper.TABLE_USERS, null, contentValues);
    }

    public Cursor fetch() {
        String[] columns = new String[] {DatabaseHelper.ID, DatabaseHelper.Fullname, DatabaseHelper.Username, DatabaseHelper.Password, DatabaseHelper.Email, DatabaseHelper.Phonenumber};
        Cursor cursor = database.query(DatabaseHelper.TABLE_USERS, columns, null,null,null, null, null);
        if (cursor !=null) {
            cursor.moveToFirst();
        }
        return cursor;
    }
}
