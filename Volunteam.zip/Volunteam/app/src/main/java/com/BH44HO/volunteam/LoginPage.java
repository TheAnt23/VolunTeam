package com.BH44HO.volunteam;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginPage extends AppCompatActivity {
    private Button button;
    private EditText UsernameEdit;
    private EditText PasswordEdit;

 DatabaseHelper db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);
        db = new DatabaseHelper( this );

        button = (Button) findViewById(R.id.SignIn);
        UsernameEdit = findViewById( R.id.Username );
        PasswordEdit = findViewById( R.id.Password );

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user =   UsernameEdit.getText().toString().trim();
                String pwd = PasswordEdit.getText().toString().trim();
                Boolean res = db.checkUser(user,pwd);
                if(res==true) {

                    Toast.makeText(LoginPage.this, "Login Successful", Toast.LENGTH_SHORT).show();
                    Intent MainActivity = new Intent(LoginPage.this,UserMenu.class);
                    startActivity(MainActivity );

                } else{

                    Toast.makeText(LoginPage.this, "Login Unsuccessful", Toast.LENGTH_SHORT).show();
                    Intent Retry = new Intent(LoginPage.this,LoginPage.class);
                    startActivity(Retry );

                }

            }
        });


    }
}
