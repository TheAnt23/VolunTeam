package com.BH44HO.volunteam;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class RegisterEvent extends AppCompatActivity implements OnClickListener {
    private Button createbtn;
    private EditText NameEdit;
    private EditText DescriptionEdit;
    private EditText TypeEdit;
    private EditText EdateEdit;
    private EditText EtimeEdit;
    private EditText LocationEdit;
    private EditText PhonenumberEdit;


    private DBManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_register_event );

        NameEdit = findViewById( R.id.Name );
        DescriptionEdit = findViewById( R.id.Description );
        TypeEdit = findViewById( R.id.Type );
        EdateEdit = findViewById( R.id.Edate );
        EtimeEdit = findViewById( R.id.Etime );
        LocationEdit = findViewById( R.id.Location );
        PhonenumberEdit = findViewById( R.id.Phone );



        createbtn = (Button) findViewById( R.id.button_create );

        dbManager = new DBManager( this );
        dbManager.open();
        createbtn.setOnClickListener( this );
    }




    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button_create:
                final String name = NameEdit.getText().toString();
                final String description = DescriptionEdit.getText().toString();
                final String type = TypeEdit.getText().toString();
                final String edate = EdateEdit.getText().toString();
                final String etime = EtimeEdit.getText().toString();
                final String location = LocationEdit.getText().toString();
                final String phonenumber = PhonenumberEdit.getText().toString();


                dbManager.insert( name, description, type, edate, etime, location, phonenumber);

                Intent main = new Intent( RegisterEvent.this, ManageEvent.class )
                        .setFlags( Intent.FLAG_ACTIVITY_CLEAR_TOP );

                startActivity( main );
                break;
        }
    }

}