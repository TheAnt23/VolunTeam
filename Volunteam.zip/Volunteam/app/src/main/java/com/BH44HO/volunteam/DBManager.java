package com.BH44HO.volunteam;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class DBManager {

    private DatabaseHelper dbHelper;
    private Context context;
    private SQLiteDatabase database;

    public DBManager(Context c){context = c;}

    public DBManager open() throws SQLException{
        dbHelper = new DatabaseHelper(context);
        database = dbHelper.getWritableDatabase();
        return this;
    }

    public void close(){dbHelper.close();}

    public void insert(String name, String description, String type, String edate, String etime, String location, String phonenumber){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.NAME, name);
        contentValues.put(DatabaseHelper.DESCRIPTION, description);
        contentValues.put(DatabaseHelper.TYPE, type);
        contentValues.put(DatabaseHelper.EDATE, edate);
        contentValues.put(DatabaseHelper.ETIME, etime);
        contentValues.put(DatabaseHelper.LOCATION, location);
        contentValues.put(DatabaseHelper.PHONENUMBER, phonenumber);
        database.insert(DatabaseHelper.TABLE_EVENT, null, contentValues);
    }
    public Cursor fetch(){
        String[] columns = new String[] {DatabaseHelper._ID, DatabaseHelper.NAME, DatabaseHelper.DESCRIPTION, DatabaseHelper.TYPE, DatabaseHelper.EDATE, DatabaseHelper.ETIME, DatabaseHelper.LOCATION, DatabaseHelper.PHONENUMBER};
        Cursor  cursor = database.query(DatabaseHelper.TABLE_EVENT, columns,null, null, null, null,null);
        if (cursor != null){
            cursor.moveToFirst();
        }
        return cursor;
    }

    public int update(long _id, String name, String description, String type, String edate, String etime, String phonenumber, String location) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper._ID, _id);
        contentValues.put(DatabaseHelper.NAME, name);
        contentValues.put(DatabaseHelper.DESCRIPTION, description);
        contentValues.put(DatabaseHelper.TYPE, type);
        contentValues.put(DatabaseHelper.EDATE, edate);
        contentValues.put(DatabaseHelper.ETIME, etime);
        contentValues.put(DatabaseHelper.LOCATION, location);
        contentValues.put(DatabaseHelper.PHONENUMBER, phonenumber);

        int i = database.update(DatabaseHelper.TABLE_EVENT, contentValues, DatabaseHelper._ID + " = " + _id, null);
        return i;
    }

    public void delete(long _id) {
        database.delete(DatabaseHelper.TABLE_EVENT, DatabaseHelper._ID + "=" + _id, null);
    }

    //Get All Events
    public List<Events> getAllEvents(){

        ArrayList<Events> events = new ArrayList<>();

        // 1. build the query
        String query = "SELECT * FROM " + DatabaseHelper.TABLE_EVENT;
        // 2. get reference to writable
        SQLiteDatabase db= dbHelper.getWritableDatabase();
        Cursor cursor= db.rawQuery(query, null);

        // 3. go over each row, build book and add it to list
        Events company_events = null;
        if (cursor!= null && cursor.moveToFirst()){
            do {
                company_events = new Events();
                company_events.setId(Integer.parseInt(cursor.getString(0)));
                company_events.setName(cursor.getString(1));
                company_events.setDescription(cursor.getString(2));
                company_events.setType(cursor.getString(3));
                company_events.setEdate(cursor.getString(4));
                company_events.setEtime(cursor.getString(5));
                company_events.setLocation(cursor.getString(6));
                company_events.setPhonenumber(cursor.getString(7));



                // Add book to books
                events.add(company_events);
            }while (cursor.moveToNext());
        }
        return events;
    }

    public Events geEvents(int id){
        Events company_events= new Events();
        // 1. get reference to readable
        SQLiteDatabase db= dbHelper.getReadableDatabase();
        // 2. build query
        Cursor cursor = db.query(DatabaseHelper.TABLE_EVENT, // a. table
                DatabaseHelper.COLUMNS, // b. column names
                " id = ?", // c. selections
                new String[] { String.valueOf(id) }, // d. selections args
                null, // e. group by
                null, // f. having
                null, // g. order by
                null); // h. limit
        // 3. if we got results get the first one
        if (cursor != null && cursor.moveToFirst())
        {
            // 4. build book object

            company_events.setId(Integer.parseInt(cursor.getString(0)));
            company_events.setName(cursor.getString(1));
            company_events.setDescription(cursor.getString(2));
            company_events.setType(cursor.getString(3));
            company_events.setEdate(cursor.getString(4));
            company_events.setEtime(cursor.getString(5));
            company_events.setLocation(cursor.getString(6));
            company_events.setPhonenumber(cursor.getString(7));


        }
        // return country
        return company_events;
    }// 5. return boo

}
