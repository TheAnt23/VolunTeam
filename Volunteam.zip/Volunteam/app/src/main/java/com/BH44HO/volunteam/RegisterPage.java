package com.BH44HO.volunteam;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class RegisterPage extends AppCompatActivity implements View.OnClickListener {

    private Button button;
    private EditText FullnameEditText;
    private EditText UsernameEditText;
    private EditText PasswordEditText;
    private EditText EmailEditText;
    private EditText PhonenumberEditText;

    private DBManagerUser dbManagerUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_page);

        dbManagerUser = new DBManagerUser( this );


        FullnameEditText = findViewById( R.id.Fullname );
        UsernameEditText = findViewById( R.id.Username );
        PasswordEditText = findViewById( R.id.Password );
        EmailEditText = findViewById( R.id.Email );
        PhonenumberEditText = findViewById( R.id.Phonenumber );

        button = (Button) findViewById(R.id.SignUp);


        button.setOnClickListener(this);
    }

    public void onClick(View v){
        switch (v.getId()) {
            case R.id.SignUp:

                final String fullname = FullnameEditText.getText().toString();
                final String username = UsernameEditText.getText().toString();
                final String password = PasswordEditText.getText().toString();
                final String email = EmailEditText.getText().toString();
                final String phonenumber = PhonenumberEditText.getText().toString();


                dbManagerUser.insert(fullname,username,password,email,phonenumber);

                Intent intent = new Intent(RegisterPage.this, LoginPage.class)
                .setFlags( Intent.FLAG_ACTIVITY_CLEAR_TOP );
                startActivity(intent);
                break;
        }
    }


}
