package com.BH44HO.volunteam;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database Information
    static final String DB_NAME = "VOLUNTEAM.DB";

    // database version
    static final int DB_VERSION = 1;

    // Table Name
    public static final String TABLE_EVENT = "events";
    public static final String TABLE_USERS = "users";
    public static final String TABLE_VOLUNTEER = "volunteer";
    public static final String TABLE_FEEDBACK = "feedback";

    //Events Table columns
    public static final String _ID = "_id";
    public static final String NAME = "name";
    public static final String DESCRIPTION = "description";
    public static final String TYPE = "type";
    public static final String EDATE = "date";
    public static final String ETIME = "time";
    public static final String LOCATION = "location";
    public static final String PHONENUMBER = "phonenumber";


    //Users Table columns
    public static final String ID = "id";
    public static final String Fullname = "fullname";
    public static final String Username = "username";
    public static final String Password = "password";
    public static final String Email = "email";
    public static final String Phonenumber = "phonenumber";

    //Volunteer Table columns
    public static final String ID_ = "id_";
    public static final String EVENT_NAME = "event_name";
    public static final String EVENT_DATE = "event_date";
    public static final String EVENT_LOCATION = "event_location";
    public static final String VOLUNTEER_NAME = "volunteer_name";
    public static final String VOLUNTEER_EMAIL = "volunteer_email";

    //Feedback Table columns
    public static final String _I_D_ = "_i_d_";
    public static final String VOLUNTEER = "volunteer";
    public static final String VOLUNTEEREMAIL = "volunteeremail";
    public static final String ORGANISER_NAME = "organiser_name";
    public static final String ORGANISER_EMAIL = "organiser_email";
    public static final String RATING = "rating";


    static final String[] COLUMNS = {_ID,NAME, DESCRIPTION, TYPE, EDATE, ETIME, LOCATION, PHONENUMBER};



    // Creating table query
    private static final String CREATE_TABLE = "create table " + TABLE_EVENT + "("
            + _ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + NAME + " TEXT NOT NULL, "
            + DESCRIPTION + " VARCHAR2 NOT NULL, "
            + TYPE + " TEXT NOT NULL, "
            + EDATE + " TEXT NOT NULL, "
            + ETIME + " TEXT NOT NULL, "
            + LOCATION + " VARCHAR2 NOT NULL, "
            + PHONENUMBER + " VARCHAR2 NOT NULL); ";

    //
    private static final String CREATE_TABLE_USERS = "create table " + TABLE_USERS + "("
            + ID  + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + Fullname + " VARCHAR2 NOT NULL, "
            + Username + " VARCHAR2 NOT NULL,"
            + Password + " VARCHAR2 NOT NULL, "
            + Email + " VARCHAR2 NOT NULL, "
            + Phonenumber + " TEXT NOT NULL); ";

    //
    private static final String CREATE_TABLE_VOLUNTEER = "create table " + TABLE_VOLUNTEER + "("
            + ID_  + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + EVENT_NAME + " VARCHAR2 NOT NULL, "
            + EVENT_DATE + " VARCHAR2 NOT NULL,"
            + EVENT_LOCATION + " VARCHAR2 NOT NULL, "
            + VOLUNTEER_NAME + " TEXT NOT NULL, "
            + VOLUNTEER_EMAIL + " VARCHAR2 NOT NULL); ";

    //
    private static final String CREATE_TABLE_FEEDBACK = "create table " + TABLE_FEEDBACK + "("
            + _I_D_  + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + VOLUNTEER + " TEXT NOT NULL, "
            + VOLUNTEEREMAIL + " VARCHAR2 NOT NULL,"
            + ORGANISER_NAME + " VARCHAR2 NOT NULL, "
            + ORGANISER_EMAIL + " VARCHAR2 NOT NULL, "
            + RATING + " TEXT NOT NULL); ";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(CREATE_TABLE);
        db.execSQL(CREATE_TABLE_USERS);
        db.execSQL(CREATE_TABLE_VOLUNTEER);
        db.execSQL(CREATE_TABLE_FEEDBACK);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENT );
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS );
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_VOLUNTEER);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FEEDBACK);
        onCreate(db);
    }

    public boolean checkUser (String username, String password) {

        String[] columns= {ID};
        SQLiteDatabase db = getReadableDatabase();
        String selection = Username + "=?" + " and " + Password + "=?";
        String[] selectionArgs = { username, password};
        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        db.close();

        if (count>0)

        {
            return true;

        } else
            return false;


    }
}
