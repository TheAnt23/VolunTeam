package com.BH44HO.volunteam;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class ManageEvent extends Activity implements OnClickListener {

    private EditText EventNameEdit;
    private EditText DescriptionEdit;
    private EditText EventTypeEdit;
    private EditText EdateEdit;
    private EditText EtimeEdit;
    private EditText LocationEdit;
    private EditText PhonenumberEdit;

    private Button updateBtn, deleteBtn;

    private long _id;

    private DBManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setTitle("Modify Record");

        setContentView(R.layout.activity_manage_event);

        dbManager = new DBManager(this);
        dbManager.open();

        EventNameEdit = findViewById( R.id.ename_edittext );
        DescriptionEdit = findViewById( R.id.edescription_edittext );
        EventTypeEdit = findViewById( R.id.etype_edittext );
        EdateEdit = findViewById( R.id.edate_edittext );
        EtimeEdit = findViewById( R.id.etime_edittext );
        LocationEdit = findViewById( R.id.location_edittext );
        PhonenumberEdit = findViewById( R.id.number_edittext );


        updateBtn = findViewById(R.id.btn_update);
        deleteBtn = findViewById(R.id.btn_delete);

        Intent intent = getIntent();
        String id = intent.getStringExtra("id");
        String ename = intent.getStringExtra("event_name");
        String edescription = intent.getStringExtra("event_description");
        String etype = intent.getStringExtra("event_type");
        String edate = intent.getStringExtra("event_date");
        String etime = intent.getStringExtra("event_time");
        String location = intent.getStringExtra("event_location");
        String number = intent.getStringExtra("event_phone_number");



        _id = Long.parseLong(id);

        EventNameEdit.setText(ename);
        DescriptionEdit.setText(edescription);
        EventTypeEdit.setText(etype);
        EdateEdit.setText(edate);
        EtimeEdit.setText(etime);
        LocationEdit.setText(location);
        PhonenumberEdit.setText(number);



        updateBtn.setOnClickListener(this);
        deleteBtn.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_update:
                String ename =EventNameEdit.getText().toString();
                String edescription =DescriptionEdit.getText().toString();
                String etype =EventTypeEdit.getText().toString();
                String edate =EdateEdit.getText().toString();
                String etime =EtimeEdit.getText().toString();
                String location =LocationEdit.getText().toString();
                String number =PhonenumberEdit.getText().toString();



                dbManager.update(_id,ename,edescription, etype, edate, etime, location, number);
                this.returnHome();
                break;

            case R.id.btn_delete:
                dbManager.delete(_id);
                this.returnHome();
                break;
        }
    }

    public void returnHome() {
        Intent home_intent = new Intent(getApplicationContext(), UserMenu.class)
                .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(home_intent);
    }
}
