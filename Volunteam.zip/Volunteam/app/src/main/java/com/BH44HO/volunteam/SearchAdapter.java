package com.BH44HO.volunteam;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class SearchAdapter extends RecyclerView.Adapter<SearchAdapter.SearchViewHolder>
        implements Filterable {
    private List<SearchItem> searchList;
    private List<SearchItem> searchListFull;

    @NonNull
    @Override
    public SearchViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_search_event, parent, false);
        return new SearchViewHolder( v );
    }




    class  SearchViewHolder extends RecyclerView.ViewHolder{
        TextView textView;
        TextView textView1;
        TextView textView2;
        TextView textView3;

        SearchViewHolder(View itemView){
            super(itemView);
            textView = itemView.findViewById( R.id.Name );
            textView1 = itemView.findViewById( R.id.Type );
            textView2 = itemView.findViewById( R.id.Edate );
            textView3 = itemView.findViewById( R.id.Location );
        }
    }

    SearchAdapter(List<SearchItem> searchList){
        this.searchList = searchList;
        searchListFull = new ArrayList<>(searchList);

    }

    @Override
    public void onBindViewHolder(@NonNull SearchViewHolder holder, int position) {
        SearchItem currentItem = searchList.get(position);

        holder.textView.setText( currentItem.getText() );
        holder.textView1.setText( currentItem.getText1() );
        holder.textView2.setText( currentItem.getText2() );
        holder.textView3.setText( currentItem.getText3() );
    }

    @Override
    public int getItemCount() {
        return searchList.size();
    }
    @Override
    public Filter getFilter() {
        return searchFilter;
    }

    private Filter searchFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            List<SearchItem> filteredList = new ArrayList<>();

            if (constraint == null || constraint.length() == 0){
                filteredList.addAll( searchListFull );
            }
            else{
                String filterPattern = constraint.toString().toLowerCase().trim();

                for (SearchItem item: searchListFull){
                    if (item.getText1().toLowerCase().contains(filterPattern)){
                        filteredList.add( item );
                    }
                }
            }
            FilterResults results = new FilterResults();
            results.values = filteredList;

            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            searchList.clear();
            searchList.addAll(( List ) results.values);
            notifyDataSetChanged();
        }
    };
}
